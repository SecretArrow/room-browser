'use strict';

// The input-form example: its manifest declares three required inputs — a
// pattern-validated email, a cadence choice and a write-only token — and its
// activation card echoes exactly what the approved form stored. The token is
// never echoed back: write-only is the promise, so the card shows the mask
// and nothing else, proving the value traveled without displaying it.

var MASK = '•••••••• (kept private)';

function fieldOf(inputs, key, fallback) {
  var value = inputs[key];
  return value === undefined || value === null || value === '' ? fallback : String(value);
}

exports.activate = async (room) => {
  var inputs = (room.meta && room.meta.inputs) || {};
  room.ui.card({
    title: 'Input Greeter is running',
    text: 'The form you approved validated these values:',
    style: 'success',
    fields: [
      ['email', fieldOf(inputs, 'email', '(none)')],
      ['cadence', fieldOf(inputs, 'choice', '(none)')],
      ['token', fieldOf(inputs, 'secret', '') === '' ? '(none)' : MASK],
    ],
  });
};
